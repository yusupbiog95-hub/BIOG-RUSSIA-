package ru.biog.russia;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.*;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    LinearLayout root;
    int white = Color.WHITE;
    int green = Color.rgb(25, 190, 91);
    int dark = Color.rgb(12, 15, 18);
    android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(Color.BLACK);
        prefs = getSharedPreferences("biog", MODE_PRIVATE);
        showLauncher();
    }

    TextView tv(String text, float size) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextColor(white); t.setTextSize(size);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    Button btn(String text, int color) {
        Button b = new Button(this);
        b.setText(text); b.setTextColor(white); b.setTextSize(16); b.setAllCaps(false);
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(18); b.setBackground(g);
        return b;
    }

    ImageView bg(int res) {
        ImageView i = new ImageView(this);
        i.setImageResource(res); i.setScaleType(ImageView.ScaleType.FIT_XY);
        return i;
    }

    void showLauncher() {
        final LauncherLayout frame = new LauncherLayout(this);
        frame.setBackgroundColor(Color.BLACK);
        frame.addView(bg(R.drawable.biog_launcher), new FrameLayout.LayoutParams(-1,-1));

        // Transparent touch zones over the artwork.
        Button topPlay = transparentButton("НАЧАТЬ ИГРУ");
        Button heroPlay = transparentButton("НАЧАТЬ ИГРУ");
        Button home = transparentButton("ГЛАВНАЯ");
        Button news = transparentButton("НОВОСТИ");
        Button shots = transparentButton("СКРИНШОТЫ");
        Button about = transparentButton("О ПРОЕКТЕ");
        Button contacts = transparentButton("КОНТАКТЫ");
        Button grozny = transparentButton("ГРОЗНЫЙ");
        Button culture = transparentButton("КУЛЬТУРА");
        Button cars = transparentButton("АВТОПАРК");
        Button mountains = transparentButton("ГОРЫ");

        frame.addView(topPlay); frame.addView(heroPlay); frame.addView(home); frame.addView(news); frame.addView(shots);
        frame.addView(about); frame.addView(contacts); frame.addView(grozny); frame.addView(culture); frame.addView(cars); frame.addView(mountains);

        View.OnClickListener play = v -> showLogin();
        topPlay.setOnClickListener(play); heroPlay.setOnClickListener(play);
        home.setOnClickListener(v -> toast("BIOG RUSSIA • Главная"));
        news.setOnClickListener(v -> toast("Новости проекта скоро появятся"));
        shots.setOnClickListener(v -> toast("Скриншоты BIOG RUSSIA"));
        about.setOnClickListener(v -> showAbout());
        contacts.setOnClickListener(v -> showSettings());
        grozny.setOnClickListener(v -> toast("Грозный • столица Чеченской Республики"));
        culture.setOnClickListener(v -> toast("Культура • традиции • уважение • сила"));
        cars.setOnClickListener(v -> toast("Автопарк BIOG RUSSIA"));
        mountains.setOnClickListener(v -> toast("Горы Чечни"));
        setContentView(frame);
    }

    Button transparentButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.TRANSPARENT);
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setContentDescription(label);
        b.setPadding(0,0,0,0);
        return b;
    }

    class LauncherLayout extends FrameLayout {
        public LauncherLayout(Context c) { super(c); }
        @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
            super.onLayout(changed,l,t,r,b);
            int w=getWidth(), h=getHeight();
            if(getChildCount()<12) return;
            layoutPct(getChildAt(1), .835f,.018f,.145f,.070f,w,h); // top play
            layoutPct(getChildAt(2), .420f,.455f,.180f,.075f,w,h); // hero play
            layoutPct(getChildAt(3), .285f,.010f,.080f,.055f,w,h); // home
            layoutPct(getChildAt(4), .505f,.010f,.085f,.055f,w,h); // news
            layoutPct(getChildAt(5), .605f,.010f,.100f,.055f,w,h); // shots
            layoutPct(getChildAt(6), .365f,.010f,.090f,.055f,w,h); // about
            layoutPct(getChildAt(7), .690f,.010f,.090f,.055f,w,h); // contacts
            layoutPct(getChildAt(8), .015f,.635f,.235f,.275f,w,h); // grozny
            layoutPct(getChildAt(9), .260f,.635f,.235f,.275f,w,h); // culture
            layoutPct(getChildAt(10), .505f,.635f,.235f,.275f,w,h); // cars
            layoutPct(getChildAt(11), .750f,.635f,.235f,.275f,w,h); // mountains
        }
        void layoutPct(View v,float x,float y,float ww,float hh,int w,int h){
            int L=(int)(x*w), T=(int)(y*h), R=(int)((x+ww)*w), B=(int)((y+hh)*h); v.layout(L,T,R,B);
        }
    }

    void showLogin() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(44,36,44,28); box.setBackgroundColor(dark);
        TextView title = tv("BIOG RUSSIA", 30); title.setTypeface(null, android.graphics.Typeface.BOLD); title.setGravity(Gravity.CENTER); box.addView(title,new LinearLayout.LayoutParams(-1,70));
        TextView server = tv("ГРОЗНЫЙ #1\n188.127.241.74:1415",16); server.setGravity(Gravity.CENTER); box.addView(server,new LinearLayout.LayoutParams(-1,80));
        EditText login = new EditText(this); login.setHint("Никнейм"); login.setText(prefs.getString("nickname", "")); login.setTextColor(Color.WHITE); login.setHintTextColor(0xFF89919B); login.setSingleLine(true); box.addView(login,new LinearLayout.LayoutParams(-1,58));
        TextView status = tv("Проверяем сервер…",14); status.setGravity(Gravity.CENTER); box.addView(status,new LinearLayout.LayoutParams(-1,55));
        Button connect=btn("ПОДКЛЮЧИТЬСЯ",green); box.addView(connect,new LinearLayout.LayoutParams(-1,58));
        Button back=btn("НАЗАД",0xFF252B35); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,55); bp.topMargin=12; box.addView(back,bp);
        setContentView(box);
        checkServer(status);
        connect.setOnClickListener(v->{String n=login.getText().toString().trim(); if(n.length()<3){login.setError("Минимум 3 символа");return;} prefs.edit().putString("nickname",n).apply(); status.setText("Подготовка клиента для "+n+"…"); new Handler().postDelayed(()->showGame(),650);});
        back.setOnClickListener(v->showLauncher());
    }

    void checkServer(TextView status) {
        new Thread(() -> {
            String result="Сервер недоступен";
            try {
                byte[] ip={ (byte)188,(byte)127,(byte)241,(byte)74 };
                byte[] q=new byte[11]; q[0]='S';q[1]='A';q[2]='M';q[3]='P'; System.arraycopy(ip,0,q,4,4); q[8]=(byte)(1415&255); q[9]=(byte)((1415>>8)&255); q[10]='i';
                DatagramSocket ds=new DatagramSocket(); ds.setSoTimeout(1800); DatagramPacket out=new DatagramPacket(q,q.length,InetAddress.getByName("188.127.241.74"),1415); ds.send(out);
                byte[] buf=new byte[2048]; DatagramPacket in=new DatagramPacket(buf,buf.length); ds.receive(in); ds.close();
                if(in.getLength()>11) { int off=11; int password=buf[11]&255; int players=(buf[12]&255)|((buf[13]&255)<<8); int max=(buf[14]&255)|((buf[15]&255)<<8); result="Сервер онлайн • "+players+" / "+max; }
            } catch(Exception ignored) {}
            final String r=result; new Handler(getMainLooper()).post(()->status.setText(r));
        }).start();
    }

    void showAbout() {
        new android.app.AlertDialog.Builder(this).setTitle("BIOG RUSSIA")
            .setMessage("ГРОЗНЫЙ #1\n\nСобственный мобильный CRMP-проект.\nВерсия лаунчера: 1.1.0\nСервер: 188.127.241.74:1415")
            .setPositiveButton("ОК", null).show();
    }

    void showSettings() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(34,24,34,20); box.setBackgroundColor(dark);
        TextView title = tv("НАСТРОЙКИ", 26); title.setTypeface(null, android.graphics.Typeface.BOLD); title.setGravity(Gravity.CENTER); box.addView(title,new LinearLayout.LayoutParams(-1,65));
        EditText nick = new EditText(this); nick.setHint("Никнейм"); nick.setText(prefs.getString("nickname", "")); nick.setTextColor(Color.WHITE); nick.setHintTextColor(0xFF89919B); nick.setSingleLine(true); box.addView(nick,new LinearLayout.LayoutParams(-1,58));
        TextView server = tv("Сервер\nГРОЗНЫЙ #1\n188.127.241.74:1415",15); server.setPadding(0,14,0,14); box.addView(server,new LinearLayout.LayoutParams(-1,100));
        Button save=btn("СОХРАНИТЬ",green); box.addView(save,new LinearLayout.LayoutParams(-1,56));
        Button close=btn("ЗАКРЫТЬ",0xFF252B35); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,52);cp.topMargin=10;box.addView(close,cp);
        setContentView(box);
        save.setOnClickListener(v->{prefs.edit().putString("nickname",nick.getText().toString().trim()).apply();toast("Настройки сохранены");showLauncher();});
        close.setOnClickListener(v->showLauncher());
    }

    void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }

    @Override public void onBackPressed() { showLauncher(); }

    void showGame() {
        final FrameLayout loading = new FrameLayout(this);
        loading.setBackgroundColor(dark);
        TextView title = tv("BIOG RUSSIA", 32);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        TextView sub = tv("ПОДКЛЮЧЕНИЕ К ГРОЗНЫЙ #1...", 14);
        sub.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1, 70, Gravity.CENTER);
        tp.topMargin = -35; loading.addView(title, tp);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-1, 50, Gravity.CENTER);
        sp.topMargin = 45; loading.addView(sub, sp);
        ProgressBar bar = new ProgressBar(this);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(70,70,Gravity.CENTER);
        bp.topMargin = 105; loading.addView(bar,bp);
        setContentView(loading);
        new android.os.Handler().postDelayed(() -> {
            GameView game = new GameView(this);
            setContentView(game);
        }, 900);
    }

    class GameView extends View {
        android.graphics.Paint p = new android.graphics.Paint(3);
        float px=520,py=430,sx=-1,sy=-1; boolean moving=false,inCar=false; float carX=700,carY=500; long last=System.currentTimeMillis();
        GameView(Context c){super(c);setFocusable(true);}
        @Override protected void onDraw(android.graphics.Canvas c){
            super.onDraw(c);
            android.graphics.Bitmap b=android.graphics.BitmapFactory.decodeResource(getResources(),R.drawable.biog_city);
            c.drawBitmap(b,null,new android.graphics.Rect(0,0,getWidth(),getHeight()),p);

            // Top player HUD
            p.setColor(0xE5080B12); c.drawRoundRect(22,18,Math.min(getWidth()-22,700),116,22,22,p);
            p.setColor(Color.WHITE); p.setTextSize(21); c.drawText("BIOG RUSSIA • ГРОЗНЫЙ #1",42,49,p);
            p.setTextSize(14); c.drawText("Новичок",42,76,p);
            p.setColor(0xFF20C968); c.drawText("₽ 100 000",125,76,p);
            p.setColor(Color.WHITE); c.drawText("HP 100",235,76,p);
            p.setColor(0xFF252B35); c.drawRoundRect(40,88,300,101,6,6,p);
            p.setColor(0xFF35D06D); c.drawRoundRect(40,88,280,101,6,6,p);

            // Mission card
            p.setColor(0xE51A2028); c.drawRoundRect(22,132,350,207,18,18,p);
            p.setColor(0xFF20C968); p.setTextSize(11); c.drawText("ТЕКУЩЕЕ ЗАДАНИЕ",40,156,p);
            p.setColor(Color.WHITE); p.setTextSize(16); c.drawText("Доберись до центра Грозного",40,181,p);
            p.setColor(0xFFB9C0C9); p.setTextSize(12); c.drawText("Награда: ₽ 2 500",40,199,p);

            // Stylized minimap
            float mx=getWidth()-105,my=105; p.setColor(0xDD11151B); c.drawCircle(mx,my,72,p);
            p.setStyle(android.graphics.Paint.Style.STROKE); p.setStrokeWidth(5); p.setColor(0xFF3A4652); c.drawCircle(mx,my,64,p);
            p.setColor(0xFF68737E); p.setStrokeWidth(3); c.drawLine(mx-50,my+35,mx+45,my-35,p); c.drawLine(mx-55,my-10,mx+50,my+28,p);
            p.setStyle(android.graphics.Paint.Style.FILL); p.setColor(0xFF20C968); c.drawCircle(mx,my,8,p);
            p.setColor(Color.WHITE); p.setTextSize(11); c.drawText("ГРОЗНЫЙ",mx-34,my+89,p);

            // Vehicle
            p.setColor(Color.BLACK); c.drawRoundRect(carX-58,carY-30,carX+58,carY+30,18,18,p);
            p.setColor(0xFFB8C0C8); c.drawRoundRect(carX-34,carY-19,carX+34,carY+15,9,9,p);
            p.setColor(Color.DKGRAY); c.drawCircle(carX-40,carY+29,13,p); c.drawCircle(carX+40,carY+29,13,p); c.drawCircle(carX-40,carY-29,13,p); c.drawCircle(carX+40,carY-29,13,p);
            p.setColor(Color.WHITE); p.setTextSize(13); c.drawText(inCar?"ВЫ ЗА РУЛЁМ":"G 63 • МАШИНА",carX-62,carY-43,p);

            if(!inCar){p.setColor(green); c.drawCircle(px,py,25,p); p.setColor(Color.WHITE); c.drawCircle(px,py,9,p); p.setTextSize(15); c.drawText("Вы",px-10,py-35,p);}

            // Joystick
            float jx=105,jy=getHeight()-115; p.setColor(0xAA1D2330); c.drawCircle(jx,jy,72,p); p.setColor(0xCCFFFFFF); c.drawCircle(jx+(moving?sx:0)*32,jy+(moving?sy:0)*32,30,p);

            String[] a={"ЧАТ",inCar?"ВЫЙТИ":"МАШИНА","РАБОТЫ"};
            for(int i=0;i<3;i++){float y=getHeight()-190+i*58; p.setColor(0xE51D2330); c.drawRoundRect(getWidth()-190,y,getWidth()-25,y+48,14,14,p); p.setColor(Color.WHITE); p.setTextSize(16); c.drawText(a[i],getWidth()-165,y+31,p);}

            if(moving){long now=System.currentTimeMillis();float dt=Math.min(40,now-last)/1000f;if(inCar){carX+=sx*330*dt;carY+=sy*330*dt;carX=Math.max(70,Math.min(getWidth()-70,carX));carY=Math.max(150,Math.min(getHeight()-50,carY));px=carX;py=carY;}else{px+=sx*220*dt;py+=sy*220*dt;px=Math.max(30,Math.min(getWidth()-30,px));py=Math.max(125,Math.min(getHeight()-30,py));}last=now;invalidate();}else last=System.currentTimeMillis();
        }
        void jobPanel(){new android.app.AlertDialog.Builder(MainActivity.this).setTitle("Работы • BIOG RUSSIA").setItems(new String[]{"Таксист • ₽ 2 500 / рейс","Курьер • ₽ 3 200 / заказ","Дальнобойщик • ₽ 8 500 / рейс","Автомеханик • ₽ 4 000 / смена"},(d,w)->toast("Работа выбрана. Система заданий будет подключена к серверу.")).setNegativeButton("Закрыть",null).show();}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){float x=e.getX(),y=e.getY();if(e.getAction()==android.view.MotionEvent.ACTION_DOWN||e.getAction()==android.view.MotionEvent.ACTION_MOVE){if(x>getWidth()-210&&y>getHeight()-75){jobPanel();return true;}if(x>getWidth()-210&&y>getHeight()-190&&y<getHeight()-120){float dx=px-carX,dy=py-carY;if(!inCar&&Math.sqrt(dx*dx+dy*dy)<180){inCar=true;px=carX;py=carY;}else if(inCar){inCar=false;px=carX+85;py=carY+65;}invalidate();return true;}if(x<220&&y>getHeight()-220){float dx=x-105,dy=y-(getHeight()-115),len=(float)Math.sqrt(dx*dx+dy*dy);if(len>8){sx=dx/len;sy=dy/len;moving=true;}invalidate();}else if(x>getWidth()-210&&y<90){showLauncher();}return true;}if(e.getAction()==android.view.MotionEvent.ACTION_UP){moving=false;sx=sy=0;invalidate();return true;}return true;}
    }
}
