# BIOG RUSSIA 1.1.0

Android Studio prototype of the BIOG RUSSIA launcher + game shell.

## Added in 1.1.0
- Persistent nickname in local app storage
- Launcher settings screen
- About/project screen
- Server status check for 188.127.241.74:1415
- Launcher -> login -> loading -> game flow

## Important
This is not a replacement for GTA: San Andreas and does not include copyrighted GTA assets. The current game view is an original prototype. A real SA-MP/CRMP mobile client requires a compatible client/engine and legally obtained game files.
